import * as FlexPlugin from 'flex-plugin';
import EmailPlugin from './EmailPlugin';

FlexPlugin.loadPlugin(EmailPlugin);
